
import { step } from 'govhk-form-core';

export default step.acknowledgement({
    
    title: ({ i }) => i`step.step_4.title`,
    
});

